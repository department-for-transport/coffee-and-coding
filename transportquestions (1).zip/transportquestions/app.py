from flask import Flask
from flask import request
from flask import jsonify
from flask import render_template
from flask_jsglue import JSGlue
import neural_net
import check_api

